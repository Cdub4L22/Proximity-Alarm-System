import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)

colors = {'RED': 0xFF0000,
          'BLUE': 0x0000FF}

R = 11
G = 13
B = 15

def setup(Rpin, Gpin, Bpin):
    global pins, p_R, p_G, p_B
    pins = {'pin_R': Rpin, 'pin_G': Gpin, 'pin_B': Bpin}
    GPIO.setmode(GPIO.BOARD)
    for i in pins:
        GPIO.setup(pins[i], GPIO.OUT)
        GPIO.output(pins[i], GPIO.HIGH)
        
    p_R = GPIO.PWM(pins['pin_R'], 2000)
    p_G = GPIO.PWM(pins['pin_G'], 2000)
    p_B = GPIO.PWM(pins['pin_B'], 2000)
    
    p_R.start(100)
    p_G.start(100)
    p_B.start(100)
    
def map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def setColor(col):
    R_val = (col & 0xff0000) >> 16
    G_val = (col & 0x00ff00) >> 8
    B_val = (col & 0x0000ff)
    
    R_val = map(R_val, 0, 255, 0, 100)
    G_val = map(G_val, 0, 255, 0, 100)
    B_val = map(B_val, 0, 255, 0, 100)
    
    p_R.ChangeDutyCycle(100 - R_val)
    p_G.ChangeDutyCycle(100 - G_val)
    p_B.ChangeDutyCycle(100 - B_val)

def off():
    for i in pins:
        GPIO.output(pins[i], GPIO.HIGH)
def destroy():
    p_R.stop()
    p_G.stop()
    p_B.stop()
    off()
    GPIO.cleanup()

def checkdist():
    GPIO.output(16, GPIO.HIGH)
    time.sleep(0.000015)
    GPIO.output(16, GPIO.LOW)
    while not GPIO.input(18):
        pass
    t1 = time.time()
    while GPIO.input(18):
        pass
    t2 = time.time()
    return (t2-t1)*340/2

GPIO.setmode(GPIO.BOARD)
GPIO.setup(16,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(18,GPIO.IN)
time.sleep(2)

try:
    setup(R,G,B)
    while True:
        print('Distance: %0.2f m' % checkdist())
        time.sleep(0.02)
        distance = checkdist()
        if distance <= 0.15:
            setColor(colors['RED'])
            time.sleep(0.5)
            setColor(colors['BLUE'])
            time.sleep(0.5)
            off()
        else:
            off()
        time.sleep(1)
except KeyboardInterrupt:
    GPIO.cleanup()